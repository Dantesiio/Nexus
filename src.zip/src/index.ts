import express from "express";
import { connectionDB } from "./lib/connectionDB";
import dotoenv from "dotenv";

async function start() {

  dotoenv.config({
    path: "./.env",
  });


await connectionDB();

const app = express();

app.get('/', (_req: express.Request, res: express.Response) => {
  res.send("Hello World");
});


app.listen(process.env.PORT, () => {
  console.log(`Server is running on port ${process.env.PORT}`);



})}

start();