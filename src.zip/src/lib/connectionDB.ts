import mongoose from "mongoose";

export async function connectionDB() {
    const db = (await mongoose.connect(process.env.DB_URI as string)).connection;
    db.on("error", console.error.bind(console, "MongoDB connection error:"));

    db.once("open", function() {
        console.log("Connected to MongoDB database");
    })
    return db;
}